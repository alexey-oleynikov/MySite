<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Упражнения по PHP</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    
    <div class="flex-container">

        <div class="header">     
               <?php include 'logo.inc.php' ?>         
               <?php include 'menu.inc.php' ?>	   
        </div>       
     
        <div class="about_me">
         
          <h1>  <?php  echo $p  ?> </h1>

            <div class="data">
                <div class="myImg">
                    <?php  echo '<img src="img/max.jpg">'; ?>
                    <?php  echo 'Подправил путь для отображения картинки'; ?>
                </div>

                <div class="fullname">
                    <p> Меня зовут 
                    <?php echo $name, ' ', $surname . '<br>'; 
                          echo 'город', ' ', $city; ?>                                      
                    </p> 
           
                    <p> Мне
                    <?php  echo $age;   ?>          
                    годика </p>
                    <p> Мы научились создавать переменные. Переменная начинается с знака $. Узнали по константы и переменные переменных</p>
                    <p> Изучили простые операции с переменными, узнали про приоритеты операций и порядок их выполнения.</p>
					<p> Разобрались, что такое операция, что такое операнд. Частично разобрались с синтаксисом языка PHP.</p>
                </div>
            </div>

            <div class="knowledge">
                                   
                    <?php  include 'knowledge.inc.php'; ?>
                    <?php   echo $a, ' ', $b + 100, ' ', '+ 100', ' ', $c, ' ', 'использовано вычисление при выводе'; ?> <br>
                                       
                    <?php
                        $a = 10;
                        $b = 20;
                        $c = $a + $b;
                        echo 'Сложение a и b', ' ', $c;
                    ?>   <br>
                    <?php
						$a = 10;
                        $b = 20;					
                        $c = $a - $b;
                        echo 'Разность a и b', ' ', $c;
                    ?>   <br>
                    <?php
						$a = 10;
                        $b = 20;					
                        $c = $a * $b;
                        echo 'Произведение a и b', ' ', $c;
                    ?>   <br>
					<?php
						$a = 10;
                        $b = 20;					
                        $c = $a / $b;
                        echo 'Частное a и b', ' ', $c;
                    ?>   <br>					
					<?php
						$a = 10;
                        $b = 20;					
                        $c = $a % $b;
                        echo 'Остаток от деления a и b', ' ', $c;
                    ?>   <br>
                     <?php
                        echo $d, ' ', 'это блок логических переменных';
                    ?>    <br>
					<?php
                        echo 'Вы в курсе дела, что есть еще куча математических действий, а и этот код непосредственно встроен в разметку?';
                    ?> 

            </div>

            <div class="article">
                <p class="text">
                    Хочется сказать, что модуль 7.8 по CSS настолько расширил мои горизонты, в голове
					кроме background и padding, только названия цветов. 
                    Постараюсь изменить стили но не творческая личность я! 
                    Простите пожалуйста меня, коли чего не так!
					Хочется еще показать чего могу, но весь в поиских...
                </p>
            </div>
        </div>

            <?php include 'footer.inc.php' ?>

    </div>


</body>
</html>
