<div class="footer">
            <h2>Мы изучили основы PHP! Мне больше понравился Python.</h2>
        </div>