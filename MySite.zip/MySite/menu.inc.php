            <nav>
                <ul>
                    <li><a href="#"> О моих поисках в PHP</a></li>
                    <li><a href="#"> Мои роботы </a></li>
                    <li><a href="#"> Мои отметки в PHP </a></li>
                    <li><a href="#"> Полезные ссылки </a></li>
                    <li><a href="#"> Связаться со мной </a></li>
                </ul>    
            </nav>