    
                <div class="logo"> 
                <img src="img/logo.png" alt="php">
                </div>                                                 
        